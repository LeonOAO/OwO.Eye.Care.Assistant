package owo.eye.care.assistant.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import owo.eye.care.assistant.data.DistanceStateStore
import owo.eye.care.assistant.overlay.DistanceOverlayController
import owo.eye.care.assistant.util.DeviceUsageMonitor
import java.util.concurrent.Executors

/** 保留已由主畫面啟動的前景服務；待機只解除相機綁定，不從解鎖廣播新建服務。 */
class DistanceForegroundService : LifecycleService() {
    private lateinit var stateStore: DistanceStateStore
    private lateinit var distanceOverlay: DistanceOverlayController
    private lateinit var usageMonitor: DeviceUsageMonitor
    private val mainExecutor by lazy { ContextCompat.getMainExecutor(this) }
    private val handler = Handler(Looper.getMainLooper())
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .build()
    )
    private var cameraProvider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    @Volatile private var active = false
    @Volatile private var destroyed = false
    @Volatile private var generation = 0
    private var tooCloseFrames = 0
    private var normalFrames = 0
    private var frameCounter = 0
    private var processing = false
    private val retry = Runnable {
        if (!destroyed && usageMonitor.isActive() && active) startCamera()
    }

    override fun onCreate() {
        super.onCreate()
        stateStore = DistanceStateStore(this)
        distanceOverlay = DistanceOverlayController(this)
        usageMonitor = DeviceUsageMonitor(this) { available ->
            active = available
            if (available) {
                stateStore.setDistancePaused(false)
                startCamera()
            } else {
                pauseCamera()
            }
            updateNotification()
        }
        stateStore.setServiceRunning(true)
        stateStore.setCameraError("")
        startForeground(2002, createNotification())
        usageMonitor.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        stateStore.setServiceRunning(true)
        return START_STICKY
    }

    /** 使舊回呼失效，解除相機並清除即時讀值；校正值與時間進度保持不變。 */
    private fun pauseCamera() {
        active = false
        generation++
        handler.removeCallbacks(retry)
        analysis?.clearAnalyzer()
        analysis?.let { cameraProvider?.unbind(it) }
        analysis = null
        distanceOverlay.hide()
        tooCloseFrames = 0
        normalFrames = 0
        frameCounter = 0
        stateStore.setLastFaceWidthPx(0)
        stateStore.setLastDistanceCm(0)
        stateStore.setDistancePaused(true)
    }

    private fun startCamera() {
        if (destroyed || !active || !usageMonitor.isActive() || analysis != null) return
        val session = ++generation
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            if (destroyed || !active || session != generation || !usageMonitor.isActive()) return@addListener
            try {
                val provider = future.get()
                cameraProvider = provider
                val useCase = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 360))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                useCase.setAnalyzer(cameraExecutor) { proxy ->
                    // ML Kit 與遮罩更新統一回到主執行緒，避免暫停和結果更新競態。
                    mainExecutor.execute {
                        frameCounter++
                        if (destroyed || !active || session != generation ||
                            !usageMonitor.isActive() || processing || frameCounter % 2 != 0) {
                            proxy.close()
                        } else {
                            @SuppressLint("UnsafeOptInUsageError")
                            val media = proxy.image
                            if (media == null) {
                                proxy.close()
                            } else {
                                processing = true
                                try {
                                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                                    detector.process(image)
                                        .addOnSuccessListener(mainExecutor) { faces ->
                                            if (!destroyed && active && session == generation && usageMonitor.isActive()) {
                                                val width = faces.maxByOrNull { it.boundingBox.width() }?.boundingBox?.width() ?: 0
                                                stateStore.setCameraError("")
                                                stateStore.setLastFaceWidthPx(width)
                                                val ref = stateStore.getRefFaceWidthPxAt30cm()
                                                if (width > 0 && ref > 0) {
                                                    val cm = (ref.toLong() * 30 / width).toInt()
                                                    stateStore.setLastDistanceCm(cm)
                                                    if (cm in 1..25) {
                                                        tooCloseFrames++
                                                        normalFrames = 0
                                                        if (tooCloseFrames >= 2) distanceOverlay.show()
                                                    } else {
                                                        normalFrames++
                                                        tooCloseFrames = 0
                                                        if (normalFrames >= 2) distanceOverlay.hide()
                                                    }
                                                } else {
                                                    stateStore.setLastDistanceCm(0)
                                                    tooCloseFrames = 0
                                                    normalFrames = 0
                                                    distanceOverlay.hide()
                                                }
                                            }
                                        }
                                        .addOnFailureListener(mainExecutor) { error ->
                                            if (!destroyed && session == generation) {
                                                stateStore.setCameraError(error.message ?: "臉部分析失敗")
                                                distanceOverlay.hide()
                                            }
                                        }
                                        .addOnCompleteListener(mainExecutor) {
                                            proxy.close()
                                            processing = false
                                            if (destroyed) detector.close()
                                        }
                                } catch (error: Exception) {
                                    processing = false
                                    proxy.close()
                                    if (!destroyed) stateStore.setCameraError(error.message ?: "影像分析失敗")
                                }
                            }
                        }
                    }
                }
                analysis = useCase
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, useCase)
                stateStore.setCameraError("")
                updateNotification()
            } catch (error: Exception) {
                analysis?.clearAnalyzer()
                analysis?.let { cameraProvider?.unbind(it) }
                analysis = null
                stateStore.setCameraError(error.message ?: "相機啟動失敗")
                updateNotification()
                handler.removeCallbacks(retry)
                handler.postDelayed(retry, 5000L)
            }
        }, mainExecutor)
    }

    override fun onDestroy() {
        destroyed = true
        usageMonitor.stop()
        pauseCamera()
        stateStore.setServiceRunning(false)
        stateStore.setDistancePaused(false)
        cameraExecutor.shutdown()
        // 在途影像先完成再關閉偵測器，避免釋放後回呼仍使用它。
        if (!processing) detector.close()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private fun updateNotification() {
        if (!destroyed) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(2002, createNotification())
        }
    }

    private fun createNotification(): Notification {
        val channelId = "owo_distance_service"
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(channelId, "護眼距離偵測服務", NotificationManager.IMPORTANCE_LOW))
        val message = when {
            stateStore.isDistancePaused() -> "待機／鎖定中：相機與距離提醒已暫停"
            stateStore.getCameraError().isNotEmpty() -> "相機暫時不可用，正在等待重試"
            else -> "正在背景監測您的用眼距離"
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("OwO 護眼距離守護中 (OwO)")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }
}
